=============================
servicenow.itsm Release Notes
=============================

.. contents:: Topics

v2.15.0
=======

Minor Changes
-------------

- CI - Add ansible-core stable-2.20 and stable-2.21 to integration and unit test matrices.
- add support for SNOW AUSTRALIA release
- api_info - Added option to preserve column names in the response. - This is a legacy behavior. If your column names are not lowercase, set this to false to preserve the original case in the response.
- tests - Drop testing of Xanadu, as it is no longer supported by the collection

v2.14.0
=======

Release Summary
---------------

Add TinyURL fallback for long GET requests, OAuth token auto-refresh for EDA rulebook activations, and an HTTP retry mechanism to the client. The inventory plugin gains a ``lowercase_hostname`` option, ``api_key`` authentication support, and verbose debug logging.

Minor Changes
-------------

- client - Automatically use ServiceNow TinyURL API (``api/now/tinyurl``) when a GET request URL exceeds 2048 characters. This allows modules like ``api_info`` to handle complex queries with many SysIDs without hitting ``414 URI Too Long`` errors. TinyURL support must be enabled on the ServiceNow instance (https://www.servicenow.com/docs/r/platform-user-interface/t_EnableTinyURLSupport.html).
- now - Add ``display.vvv`` debug logging to the inventory plugin. When running with ``-vvv``, logs the request URL, API response latency, response parse time, and per-batch pagination progress to help diagnose slow inventory syncs.
- now - Add ``lowercase_hostname`` option to the inventory plugin to convert hostnames to lowercase for consistent naming across mixed-case ServiceNow records.
- now - return nothing in add_host when record is an empty data type or of NoneType

Bugfixes
--------

- plugins/inventory/now - Add support for api_key authentication in the inventory plugin. Fixes https://github.com/ansible-collections/servicenow.itsm/issues/527

v2.13.2
=======

Release Summary
---------------

Allow ServiceNow timezone to be passed via parameter (remote_servicenow_timezone) to the plugin. Clarify error message to indicate that it must be set explicitly (that is, not to the system default) in the ServiceNow user record if not passed in via parameter.

Bugfixes
--------

- records - Timezone lookup now uses a new parameter (remote_servicenow_timezone), then checks explicit user timezone in ServiceNow, then checks system default timezone in ServiceNow. Errors if none of these are set. (https://github.com/ansible-collections/servicenow.itsm/issues/516)

v2.13.1
=======

Release Summary
---------------

Fix memory leak issues in client code and consequently also in the EDA records query plugin.

Bugfixes
--------

- eda/records - Fix bug where the plugin would incorrectly report records and fail to restart (https://github.com/ansible-collections/servicenow.itsm/pull/511)
- eda/records, client - Fix memory leaks (https://github.com/ansible-collections/servicenow.itsm/pull/513)

v2.13.0
=======

Release Summary
---------------

The collection now supports the Zurich ServiceNow release, which has been added to the test matrix. The ServiceNow Washington release has gone EOL so it has been dropped. Also drop ansible-core 2.17 from test matrix as it is going EOL.

Minor Changes
-------------

- add support for SNOW ZURICH release

v2.12.1
=======

Bugfixes
--------

- api - Remove six imports since py2 support is not needed
- client, validation - Remove six imports since py2 support is not needed
- eda/plugins/event_source/records - Add meta file so EDA plugin docs will be parsed by Galaxy (fixes https://github.com/ansible-collections/servicenow.itsm/issues/498)
- records - Prevent missed events between polls by avoiding future 'since' timestamps; advance the 'since' timestamp (cursor) to the latest seen value at second precision (monotonic). (issue

v2.12.0
=======

Release Summary
---------------

Add Event-Driven Ansible record polling feature and fix some CI/CD issues.

Minor Changes
-------------

- records - add EDA event source plugin that allows you to monitor a table for new or updated records

v2.11.0
=======

Minor Changes
-------------

- The ServiceNow connection now defaults to a 10 second timeout if the `timeout` parameter is not set and the `SN_TIMEOUT` environment variable is not provided.
- This affects all modules and plugins that use the shared instance connection options.
- catalog_request - Add module to manage ServiceNow catalog requests
- catalog_request_info - Add module to gather information about ServiceNow catalog requests
- catalog_request_task - Add module to manage ServiceNow catalog request tasks
- catalog_request_task_info - Added module to retrieve information about ServiceNow tasks in a catalog request
- now - added enhanced_sysparm_limit option to now inventory plugin, allowing control of the maximum number of relationship records returned in a single query when using enhanced.
- plugins/inventory/now - Added support for the client certificate authentication
- plugins/module_utils/client - Added support for the client certificate authentication (https://github.com/ansible-collections/servicenow.itsm/issues/415)

Bugfixes
--------

- configuration_item - use sys_class_name when getting existing records instead of always querying cmdb_ci

New Modules
-----------

- servicenow.itsm.catalog_request_info - List ServiceNow catalog requests
- servicenow.itsm.catalog_request_task - Manage ServiceNow catalog request tasks
- servicenow.itsm.catalog_request_task_info - List ServiceNow catalog request tasks

v2.10.0
=======

Release Summary
---------------

Enhancements to inventory process to be able to limit relationship scope for enhanced queries and add some authentication options including apikey and oauth mechanisms.

Minor Changes
-------------

- authentication - Added configurable token_auth_method parameter to support both x-sn-apikey and Authorization Bearer headers for access tokens (https://github.com/ansible-collections/servicenow.itsm/issues/416)
- authentication - Adds support for the OAUTH client_credentials grant type
- plugins/inventory/now - Add support for ansible-core 2.19 in the inventory plugin
- plugins/inventory/now - Added additional parameters to allow the user to configure the enhanced query and additional columns
- plugins/inventory/now - Added support for the client_credentials authentication grant type
- plugins/inventory/now - allow accessing dot variables by underscore alias in compose (https://github.com/ansible-collections/servicenow.itsm/issues/428)

v2.9.3
======

Release Summary
---------------

Fix regression in inventory plugin, and refactor inventory tests to be run as GitHub Actions

Bugfixes
--------

- Correct regression due to data-tagging changes for ansible-core 2.19 (Fixes

Known Issues
------------

- Version 2.9.3 has a known issue with the inventory plugin for (as-yet unreleased) ansible-core 2.19. (#460)

v2.9.2
======

v2.9.1
======

Release Summary
---------------

Bugfix release for #451

Bugfixes
--------

- inventory plugin - fix a syntax issue that causes the plugin to fail (https://github.com/ansible-collections/servicenow.itsm/issues/451)

v2.9.0
======

Minor Changes
-------------

- plugins/action/api - Mark the template field as a trusted template source. This was the default behaviour of ansible-core until 2.19
- plugins/modules/change_request_task - Throw an error if state=='pending' and on_hold=True, like the documentation says

Bugfixes
--------

- Adding support in ansible-version 2.18, python version 3.11
- Adding support in ansible-version 2.18, python version 3.12
- Adding support in ansible-version 2.18, python version 3.13
- Removing support in ansible-version 2.14
- Update the unit tests to be compatible with ansible-core 2.19

Known Issues
------------

- In YOKOHAMA, when state is RESOLVED/CLOSED and resolution_params is risk_accepted it fails on not having "fix_notes".
- Issue is open in collection https://github.com/ansible-collections/servicenow.itsm/issues/448
- This happens only in YOKOHAMA.
- This looks like an api change.

v2.8.0
======

Release Summary
---------------

Introduce feature to limit how many columns are retrieved by inventory queries, which can substantially improve inventory performance. Also includes changes to improve the integration test framework and enhance the release script.

Minor Changes
-------------

- inventory - The inventory plugin now supports limiting the number of columns returned in the query. Users who wish to use this feature in conjunction with compose will need to add columns referenced by compose to the query additional_columns option. The default case preserves backwards compatibility by not limiting the columns returned. (https://github.com/ansible-collections/servicenow.itsm/pull/422)

Bugfixes
--------

- tests - Fix problem and problem_task integration tests to be deterministic when being run in multithreaded environmnts (https://github.com/ansible-collections/servicenow.itsm/pull/421)

v2.7.0
======

Release Summary
---------------

Add optional aggregation feature to inventory; add ServiceNow Xanadu to integration test matrix

Minor Changes
-------------

- inventory - allow inventory to aggregate multiple hostvars for the same host. (https://github.com/ansible-collections/servicenow.itsm/pull/408)
- tests - Add ServiceNow Xanadu release to test matrix

v2.6.3
======

Release Summary
---------------

Fix docs issue with 2.6.2 release

v2.6.2
======

Release Summary
---------------

Fix issue with service_catalog endpoint and remove SNOW Tokyo from test matrix

Deprecated Features
-------------------

- tests - Drop sanity test override matrix, as the inherited job now has the correct excludes
- tests - Drop testing of Tokyo, as it is no longer supported by ServiceNow

Bugfixes
--------

- Correct submit_order endpoint for issue

v2.6.1
======

Release Summary
---------------

Fix incorrect documentation shipped with 2.6.0

Bugfixes
--------

- docs - Documentation generated for 2.6.0 was incorrect due to maintainer error. This updates the documentation to be correct and consistent.

v2.6.0
======

Release Summary
---------------

Introduce service_catalog modules; fix inventory crash bug and improve performance by handling duplicate records better

Minor Changes
-------------

- Added check for records(sys_id) that are already processed with reference records
- Raise Ansible runtime version to 2.15.0 in accordance with Ansible Lifecycle policy. This implies dropping Python 3.9 from the test matrix as well.
- ServiceNow returns duplicated records causing error at line referenced.pop("sys_id")
- Update authors in galaxy.yml

Bugfixes
--------

- now - Fix crash of inventory when query is present (https://github.com/ansible-collections/servicenow.itsm/issues/361).

New Modules
-----------

- servicenow.itsm.service_catalog - Manage ServiceNow service catalog cart
- servicenow.itsm.service_catalog_info - List ServiceNow service catalogs along with categories and items

v2.5.0
======

Release Summary
---------------

Introduce generic API client, test against all current releases of ServiceNow, and introduce support for Event-Driven Ansible Notification Service (aka EDA NS) application

Minor Changes
-------------

- Added option to allow changing sysparm_limit for table query (https://github.com/ansible-collections/servicenow.itsm/pull/309).
- Included integration tests and instances targeting the following ServiceNow releases: Washington, Vancouver, Utah, Tokyo
- api - allow `api` module to make request outside `Table API` namespace(https://github.com/ansible-collections/servicenow.itsm/pull/314).
- api_info - allow `api_info` module to make request outside `Table API` namespace(https://github.com/ansible-collections/servicenow.itsm/pull/314).
- change_request - allow change_request_mapping for category parameter (https://github.com/ansible-collections/servicenow.itsm/issues/266).
- client - allow user to pass a `object_hook` function to rest client for custom decoding of the json response(https://github.com/ansible-collections/servicenow.itsm/pull/316).
- configuration_item_relations - add module to add and remove relations between configuration items.
- configuration_item_relations_info - add module retrieve relations of a configuration item.
- now - add cache support for the inventory plugin (https://github.com/ansible-collections/servicenow.itsm/pull/315).
- now.py - replace "." in reference field column name to "_" in host variable

Bugfixes
--------

- now - Fix crash when SN_TIMEOUT is set because is it passed as string instead of a number (https://github.com/ansible-collections/servicenow.itsm/pull/348).

New Modules
-----------

- servicenow.itsm.configuration_item_relations - Manage ServiceNow relations between configuration items
- servicenow.itsm.configuration_item_relations_info - Retreive ServiceNow relations of configuration items

v2.4.0
======

Minor Changes
-------------

- Updated release script for servicenow collection.
- api - added custom headers and api path to the given request (https://github.com/ansible-collections/servicenow.itsm/pull/239).
- use get_record_by_sys_id instead of get_record in methods update, delete (https://github.com/ansible-collections/servicenow.itsm/pull/307).

Bugfixes
--------

- change_request - allow query assignment_group by sys_id (https://github.com/ansible-collections/servicenow.itsm/issues/295)
- change_request_task - allow query assignment_group by sys_id (https://github.com/ansible-collections/servicenow.itsm/issues/295)
- change_request_task - remove duplicate option 'testing' from 'type' argument_spec.
- configuration_item_info - allow user to specify limited return fields for the specified configuration item (https://github.com/ansible-collections/servicenow.itsm/pull/208).
- incident - allow incident_mapping for close_code parameter.
- now - added missing SN_SYSPARM_QUERY environment variable (https://github.com/ansible-collections/servicenow.itsm/issues/293).
- table_client - Fix 'KeyError' exception when fetching records by sys_id and add `must_have` arguments (https://github.com/ansible-collections/servicenow.itsm/pull/306)

v2.3.0
======

Release Summary
---------------

This is the minor release of the ``servicenow.itsm`` collection.
This changelog contains all changes to the modules in this collection that
have been added after the release of ``servicenow.itsm`` 2.2.0.

Minor Changes
-------------

- Add validate_certs option to instance (https://github.com/ansible-collections/servicenow.itsm/pull/264).
- Added option to pass OAuth2 access token previously obtained from ServiceNow (https://github.com/ansible-collections/servicenow.itsm/pull/272).

Bugfixes
--------

- Fix issue with attachment_upload module not working properly (https://github.com/ansible-collections/servicenow.itsm/pull/260).
- now - use correct environment variable for SN_CLIENT_SECRET (https://github.com/ansible-collections/servicenow.itsm/issues/261).

v2.2.0
======

Release Summary
---------------

This is the minor release of the ``servicenow.itsm`` collection.
This changelog contains all changes to the modules in this collection that
have been added after the release of ``servicenow.itsm`` 2.1.0.

Minor Changes
-------------

- Added attachment_upload module (https://github.com/ansible-collections/servicenow.itsm/pull/248).

New Modules
-----------

- servicenow.itsm.attachment_upload - Upload attachment to the selected table

v2.1.0
======

Release Summary
---------------

This is the minor release of the ``servicenow.itsm`` collection.
This changelog contains all changes to the modules in this collection that
have been added after the release of ``servicenow.itsm`` 2.0.0.

Minor Changes
-------------

- api - Added parameter query_params to api module (https://github.com/ansible-collections/servicenow.itsm/pull/225).
- inventory plugin - Plugin now supports mapping of reference fields inside 'compose' block.

Bugfixes
--------

- inventory plugin - sysparm_query attribute is taken into account.
- mapping - When creating custom mapping, one can list unknown fields and map them to values. Before the fix there was a bug, where one could only rename fields inside mapping.

v2.0.0
======

Release Summary
---------------

This is the major release of the ``servicenow.itsm`` collection.

Minor Changes
-------------

- Attachment integration tests - Add missing register variables (https://github.com/ansible-collections/servicenow.itsm/pull/194)
- TableClient - Remove hardcoded value of sysparm_exclude_reference_link when querying on table api.
- \*_info modules - Added additional module parameter sysparm_display_value to all info modules, which, if set to either true or all, enables the user to see the values of sys_tags.
- \*_info modules - Added field sysparm_query, which represents an encoded query string used to filter the results as an alternative to C(query) (https://github.com/ansible-collections/servicenow.itsm/pull/190).
- api - Added module api, which essentially codifies the ServiceNow REST API explorer in Ansible-native way for POST, PATCH and DELETE operations.
- api - Enhanced api module with template processing capabilities as an alternative to its data parameter for creating or updating a resource (https://github.com/ansible-collections/servicenow.itsm/pull/201).
- api_info - Added module api_info, which essentially codifies the ServiceNow REST API explorer in Ansible-native way for retrieving records (GET operations).
- attachment integration tests - Adapt integration tests for attachment module due to changes on PR 192 (https://github.com/ansible-collections/servicenow.itsm/pull/193)
- configuration_batch_item - now returns result instead only if something was changed or not.
- configuration_item_info - Added option name to simplify queries based on that parameter.
- module_utils/attachments.py - Add ``get_attachment`` and ``save_attachment`` (https://github.com/ansible-collections/servicenow.itsm/pull/186).
- module_utils/problem.py - Added problem client for requesting problem state updates from the I(API for Red Hat Ansible Automation Platform Certified Content Collection) Scripted REST API Service.
- module_utils/util.py - Added optional Boolean parameter C(implicit) to C(get_mapper) function to provide default values for missing keys in the mapping.
- modules/problem.py - Added module parameters validation to match the mapping specification.
- modules/problem.py - Added optional module parameter C(base_api_path) to control the URI prefix of the endpoint exposed by the I(API for Red Hat Ansible Automation Platform Certified Content Collection) Scripted REST API Service.
- now - Added field sysparm_query, which represents an encoded query string used to filter the results as an alternative to C(query) (https://github.com/ansible-collections/servicenow.itsm/pull/190).
- test_api - Remove unused import which caused sanity error. (https://github.com/ansible-collections/servicenow.itsm/pull/204)

Breaking Changes / Porting Guide
--------------------------------

- configuration_item - Added name as a unique identifier. This means that the idempotence is based on name, while previously there was no idempotence (except for sys_id). When state=present if a configuration item with given name does not exist, the item is created. If it already exists, it is updated. (https://github.com/ansible-collections/servicenow.itsm/pull/192)
- plugins/inventory/now.py - Removed parameters ``ansible_host_source``, ``named_groups`` and ``group_by`` (https://github.com/ansible-collections/servicenow.itsm/pull/213).

Bugfixes
--------

- modules/problem.py - Uses I(API for Red Hat Ansible Automation Platform Certified Content Collection) Scripted REST API Service for transitioning problem state in case of Table API fails.

New Modules
-----------

- servicenow.itsm.api - Manage ServiceNow POST, PATCH and DELETE requests
- servicenow.itsm.api_info - Manage ServiceNow GET requests
- servicenow.itsm.attachment - a module that users can use to download attachment using sys_id

v1.4.0
======

Release Summary
---------------

This is the minor release of the ``servicenow.itsm`` collection.

Minor Changes
-------------

- added ignore.txt for Ansible 2.14 devel branch.
- now - Updated documents to make clear how AND OR queries operate.
- now - fix mapped attributes in now modules.
- now - fix validate-modules errors in now inventory plugins.
- now - inventory plugin updated to support ``refresh_token`` and ``grant_type`` (https://github.com/ansible-collections/servicenow.itsm/issues/168).

v1.3.3
======

Release Summary
---------------

This is the patch release of the ``servicenow.itsm`` collection.

v1.3.2
======

Release Summary
---------------

This is the patch release of the ``servicenow.itsm`` collection.

v1.3.1
======

Release Summary
---------------

This is the patch release of the ``servicenow.itsm`` collection.

v1.3.0
======

Release Summary
---------------

This is the minor release of the ``servicenow.itsm`` collection.
This changelog contains all changes to the modules in this collection that
have been added after the release of ``servicenow.itsm`` 1.2.0.

Minor Changes
-------------

- client - Changed the base URL path of the HTTP client for all requests from `/api/now` to `/`
- now - Enhance inventory with additional groups from CMDB relations (https://github.com/ansible-collections/servicenow.itsm/issues/108).
- table.py - add change_request and configuration item search options.

New Modules
-----------

- servicenow.itsm.change_request_task - Manage ServiceNow change request tasks
- servicenow.itsm.change_request_task_info - List ServiceNow change request tasks
- servicenow.itsm.problem_task - Manage ServiceNow problem tasks
- servicenow.itsm.problem_task_info - List ServiceNow problem tasks

v1.2.0
======

Release Summary
---------------

This is the minor release of the ``servicenow.itsm`` collection.
This changelog contains all changes to the modules in this collection that
have been added after the release of ``servicenow.itsm`` 1.1.0.

Minor Changes
-------------

- attachments - Add a client for attachment management. Add support for attachments in change_request, configuration_item, incident and problem modules, including their info counterparts. (https://github.com/ansible-collections/servicenow.itsm/pull/91)

Deprecated Features
-------------------

- now inventory plugin - deprecate non constructed features (https://github.com/ansible-collections/servicenow.itsm/pull/97).

Bugfixes
--------

- change_request - validates on_hold with its respective field instead of a non-existent "on_hold" state when requiring a hold_reason (https://github.com/ansible-collections/servicenow.itsm/pull/86).
- client - Lowercase all header dict keys on Response initialization for better consistency across Python versions. Fix tests and table client accordingly (https://github.com/ansible-collections/servicenow.itsm/pull/98).
- now - add support for constructed feature in inventory plugin (https://github.com/ansible-collections/servicenow.itsm/issues/35).

New Modules
-----------

- servicenow.itsm.configuration_item_batch - Manage ServiceNow configuration items in batch mode

v1.1.0
======

Release Summary
---------------

v1.1.0 release for ServiceNow ITSM collection.

Minor Changes
-------------

- Added new query module utility to filter results in info modules (https://github.com/ansible-collections/servicenow.itsm/issues/66).
- Added query parameter to change request info module
- Added query parameter to configuration item info module
- Added query parameter to incident info module
- Added query parameter to problem info module
- Added support for ``refresh_token`` in login mechanism (https://github.com/ansible-collections/servicenow.itsm/issues/63).

Bugfixes
--------

- now - check instance host value before making REST call from the Client (https://github.com/ansible-collections/servicenow.itsm/pull/79).

v1.0.0
======

New Plugins
-----------

Inventory
~~~~~~~~~

- servicenow.itsm.now - Inventory source for ServiceNow table records.

New Modules
-----------

- servicenow.itsm.change_request - Manage ServiceNow change requests
- servicenow.itsm.change_request_info - List ServiceNow change requests
- servicenow.itsm.configuration_item - Manage ServiceNow configuration items
- servicenow.itsm.configuration_item_info - List ServiceNow configuration item
- servicenow.itsm.incident - Manage ServiceNow incidents
- servicenow.itsm.incident_info - List ServiceNow incidents
- servicenow.itsm.problem - Manage ServiceNow problems
- servicenow.itsm.problem_info - List ServiceNow problems
